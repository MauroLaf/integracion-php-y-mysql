<?php//variable para identificar donde esta la img que voy a utilizar como base para generar la img en miniatura
$scr_img = imagecreatefromjpeg("unidad4.jpg"); //imagen de origen (source)referenciamos la ruta y creamos la imagen
// Obtenemos las dimensiones de la imagen original
$alto_original = imagesy($scr_img);
$ancho_original = imagesx($scr_img);
//definimos medidas exactas de la imagen que utilizara la img mini
$alto_min = 150;
$ancho_min = 150;
//imagen de destino
$dst_img = imagecreatetruecolor ($ancho_min, $alto_min);
$imagen = imagecreate ($ancho_min, $alto_min);
//damos tamaño a la imagen min (destino, original, tamaño de los ejes la img min, ancho  y alto de la img de destino, ejes x e y de la img original)
imagecopyresized ($dst_img, $scr_img, 0, 0, 0, 0, $ancho_min, $alto_min, imagesx ($scr_img), imagesy ($scr_img));
imagejpeg ($dst_img, __DIR__ ."unidad4_thumb.jpg");//definimos la nueva imagen, es decir la creamos. PARA QUE SE CREE ES NECESARIO HACER REF A LA img original (unidad4)_nombre.jpg
$ruta_thumb = __DIR__ . "/thumb.jpg";
imagejpeg($dst_img, $ruta_thumb);
imagedestroy($scr_img);
imagedestroy ($dst_img); //sacamos de la memoria la imagen
?>