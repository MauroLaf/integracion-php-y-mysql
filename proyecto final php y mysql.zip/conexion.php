<?php
$conexion_unidad = mysqli_connect("localhost", "root", "", "phpavanzado") or
exit ("Error, no se pudo conectar a la base de datos");
?>