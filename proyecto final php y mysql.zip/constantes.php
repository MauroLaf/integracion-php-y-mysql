<?php
define('SERVIDOR', 'localhost');
define('USUARIO', 'root');
define('PASS', '');
define('BASE', 'phpavanzado');
?>
