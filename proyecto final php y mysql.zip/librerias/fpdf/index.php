<!DOCTYPE html>
<html>
<head>
	<title>Ejemplos Unidad 8</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="../estilos.css">
</head>
<body>
	<main class="container">
<header>
	<h2>Ejemplos Unidad 8</h2>
	<nav>
	<ul>
		<li><a href="../index.php">Volver a Ejemplos Unidad 8</a></li>		
	
	</ul>
	</nav>
</header>
<section>
	<h1>Pagination</h1>
	<nav id="botonera_pdf">
		<ul>
			<li><a href="ejemplo1.php" target="_blank">Ejemplo 1</a></li>
			<li><a href="ejemplo2.php" target="_blank">Ejemplo 2</a></li>
			<li><a href="ejemplo3.php" target="_blank">Ejemplo 3</a></li>
			<li><a href="ejemplo4.php" target="_blank">Ejemplo 4</a></li>
			<li><a href="ejemplo5.php" target="_blank">Ejemplo 5</a></li>
		</ul>
	</nav>
</section>
</main>
</body>
</html>