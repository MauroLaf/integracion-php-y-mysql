<?php
//inclusion de archivos
include("constantes.php");
include("basededatos.php");
include("producto.php");
include("carrito.php"); 

//definir constantes

define('SERVIDOR','localhost');
define('USUARIO','root');
define('PASS','');
define('BASE','phpavanzado');
?>
